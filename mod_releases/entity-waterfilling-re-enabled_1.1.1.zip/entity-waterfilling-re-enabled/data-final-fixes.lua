local pp_data_util = require("__space-exploration-postprocess__.data_util")

-- Stops Non-Space Tiles (Space Platform, Spaceship Platform, Etc) From Being
-- Replaced Or Removed When An Entity Is On Them

--for _, tile in pairs(data.raw.tile) do
--  if not pp_data_util.table_contains(tile.collision_mask, space_collision_layer) then
--    tile.check_collision_with_entities = false
--  end
--end

for _, tile in pairs(data.raw.tile) do
  if pp_data_util.table_contains(tile.collision_mask, "water-tile") then
    tile.check_collision_with_entities = false
  end
end
