 -- calls fix script
require("fix")
